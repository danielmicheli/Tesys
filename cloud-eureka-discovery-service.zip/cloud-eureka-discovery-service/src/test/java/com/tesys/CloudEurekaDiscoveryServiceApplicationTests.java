package com.tesys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudEurekaDiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
